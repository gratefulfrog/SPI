SLIP
====

Scripts to communicate with serial ports according to SLIP protocol. Source: http://recolog.blogspot.de/2012/10/serial-line-internet-protocol-slip.html
